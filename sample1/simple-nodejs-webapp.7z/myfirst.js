var http = require('http');
var dt = require('./myfirstmodule');
var cts = require('./constants');
var url = require('url');

function sayHello()
{
    console.log("Hello world");
}

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(req.url + cts.HTML_P);
  var q = url.parse(req.url, true);
  var text = q.query.year + " " + q.query.month;
  res.write( text + cts.HTML_P);
  res.end('The date and time is: ' + dt.myDateTime());
}).listen(8080);